// let currentIndex = 0;
// const slides = document.querySelectorAll('.slide');
// const totalSlides = slides.length;
// const slider = document.getElementById('slider');

// function changeSlide(offset) {
//   currentIndex = (currentIndex + offset) % totalSlides;
//   if (currentIndex < 0) {
//     currentIndex = totalSlides - 1;
//   }
//   const position = -currentIndex * 100;
//   slider.style.transform = `translateX(${position}%)`;
// }

// // Auto move to the next slide every 1.5 seconds
// setInterval(() => {
//   currentIndex = (currentIndex + 1) % totalSlides;
//   const position = -currentIndex * 100;
//   slider.style.transform = `translateX(${position}%)`;
// }, 1500);


// Scroll to Top Button functionality
const scrollToTopBtn = document.getElementById('scrollToTopBtn');
const rootElement = document.documentElement;

function handleScroll() {
  // Show the button when the user scrolls down 100px from the top of the document
  if (rootElement.scrollTop > 100) {
    scrollToTopBtn.style.display = "block";
  } else {
    scrollToTopBtn.style.display = "none";
  }
}

function scrollToTop() {
  // Scroll to the top of the document
  rootElement.scrollTo({
    top: 0,
    behavior: "smooth"
  }); 
}

scrollToTopBtn.addEventListener("click", scrollToTop);
document.addEventListener("scroll", handleScroll);

