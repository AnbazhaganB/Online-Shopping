// Scroll to Top Button functionality
const scrollToTopBtn = document.getElementById('scrollToTopBtn');
const rootElement = document.documentElement;

function handleScroll() {
  // Show the button when the user scrolls down 100px from the top of the document
  if (rootElement.scrollTop > 100) {
    scrollToTopBtn.style.display = "block";
  } else {
    scrollToTopBtn.style.display = "none";
  }
}

function scrollToTop() {
  // Scroll to the top of the document
  rootElement.scrollTo({
    top: 0,
    behavior: "smooth"
  }); 
}

scrollToTopBtn.addEventListener("click", scrollToTop);
document.addEventListener("scroll", handleScroll);



// Ensure the DOM is fully loaded before executing the script
document.addEventListener('DOMContentLoaded', function() {
  // Select all buttons with the class "buttonmf"
  const buttons = document.querySelectorAll('.buttonmf');

  // Loop through each button and add the click event listener
  buttons.forEach(function(button) {
      button.addEventListener('click', function() {
          // Display an alert message
          alert('Your order successfully added!');
      });
  });
});
